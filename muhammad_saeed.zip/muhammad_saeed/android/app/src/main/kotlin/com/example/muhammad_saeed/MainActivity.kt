package com.example.muhammad_saeed

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
